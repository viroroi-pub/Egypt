# Monte Carlo headway update

This package implements the dynamic average headway rule used in the C# model:

```text
dynamic_average_headway = max(AverageHeadway, physics_headway_min)
```

where:

```text
physics_headway_min = physics_safety_dist / ramp_speed / 60
physics_safety_dist = team_length + sledge_length + dynamic_buffer
team_length = ceil(workers / 2) * 1.5 - 1.0
```

The deterministic reference remains the published adaptive 4-min case:

```text
REF_YEARS = 13.30235
REF_HEADWAY = 4.0 min
```

The scenario duration is scaled by:

```text
base_duration = REF_YEARS * dynamic_average_headway / REF_HEADWAY
```

For mu = 0.30 and theta = 7 deg:

```text
physics_safety_dist = 41.0 m
physics_headway_min = 4.5556 min
dynamic_average_headway(4-min case) = 4.5556 min
dynamic_average_headway(6-min case) = 6.0 min
```

Thus, lower nominal headways are limited by safety spacing, while 6-min scenarios are not further increased by friction/slope when the safety headway is already below 6 min.
