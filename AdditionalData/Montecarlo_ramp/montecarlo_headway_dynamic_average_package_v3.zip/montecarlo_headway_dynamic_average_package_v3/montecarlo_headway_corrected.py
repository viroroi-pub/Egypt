import csv
import math
from pathlib import Path

import numpy as np
import pandas as pd


BLOCK_MASS_KG = 2267.96
G = 9.80665
RAMP_SPEED_M_PER_S = 0.15
PULLER_FORCE_N = 300.0
PULLERS_PER_ROW = 2
PAIR_SPACING_M = 1.5
SLEDGE_LENGTH_M = 6.0
DYNAMIC_BUFFER_M = 12.0
TABLE2_PULLERS = {
    (0.20, 6.0): 23,
    (0.30, 6.0): 30,
    (0.20, 7.0): 24,
    (0.30, 7.0): 32,
    (0.20, 8.0): 25,
    (0.30, 8.0): 33,
}

REF_MU = 0.20
REF_THETA_DEG = 7.0
REF_HEADWAY_MIN = 4.0
REF_YEARS = 13.30235
N_TRIALS = 10000
SEED = 42

BASE_MEN = 24


def ramp_force_n(mu: float, theta_deg: float) -> float:
    theta = math.radians(theta_deg)
    return BLOCK_MASS_KG * G * (math.sin(theta) + mu * math.cos(theta))


def round_to_int(value: float) -> int:
    """Equivalent to Unity's practical Mathf.RoundToInt for positive values."""
    return int(math.floor(value + 0.5))


def pull_force_per_man_n() -> float:
    return ramp_force_n(REF_MU, REF_THETA_DEG) / BASE_MEN


def pullers_required(mu: float, theta_deg: float) -> int:
    if (mu, theta_deg) in TABLE2_PULLERS:
        return TABLE2_PULLERS[(mu, theta_deg)]
    return round_to_int(ramp_force_n(mu, theta_deg) / pull_force_per_man_n())


def team_length_m(pullers: int) -> float:
    rows = math.ceil(pullers / PULLERS_PER_ROW)
    return rows * PAIR_SPACING_M - 1.0


def team_length_from_scenario_m(mu: float, theta_deg: float) -> float:
    return team_length_m(pullers_required(mu, theta_deg))


def safety_distance_m(mu: float, theta_deg: float) -> float:
    return team_length_from_scenario_m(mu, theta_deg) + SLEDGE_LENGTH_M + DYNAMIC_BUFFER_M


def safety_headway_min(mu: float, theta_deg: float) -> float:
    return safety_distance_m(mu, theta_deg) / RAMP_SPEED_M_PER_S / 60.0


def dynamic_average_headway_min(mu: float, theta_deg: float, nominal_headway_min: float) -> float:
    """Effective average headway used by Monte Carlo.

    This implements the same logic as the C# dynamic_average_headway:
    keep the nominal operational headway unless the physical team footprint
    requires a longer minimum safety headway.
    """
    return max(nominal_headway_min, safety_headway_min(mu, theta_deg))


def base_years(mu: float, theta_deg: float, nominal_headway_min: float) -> float:
    """Central deterministic duration anchored to the published 4-min case."""
    return REF_YEARS * dynamic_average_headway_min(mu, theta_deg, nominal_headway_min) / REF_HEADWAY_MIN


def load_or_generate_stop_factor(n: int = N_TRIALS, seed: int = SEED) -> pd.Series:
    template = Path("/workspace/.cache/01-montecarlo_edge_ramp_trials_mu0p15_theta6_10000.csv")
    if template.exists():
        df = pd.read_csv(template)
        if "stop_factor" in df.columns:
            return df["stop_factor"].head(n).copy()

    rng = np.random.default_rng(seed)
    return pd.Series(rng.lognormal(mean=math.log(1.011), sigma=0.021, size=n))


def run_scenarios(
    mus=(0.30,),
    thetas=(6.0, 7.0, 8.0),
    headway_cases=(4.0, 6.0),
    out_dir=Path("/workspace/montecarlo_headway_corrected"),
) -> tuple[pd.DataFrame, pd.DataFrame]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stop_factor = load_or_generate_stop_factor()
    rng = np.random.default_rng(SEED)
    all_trials = []
    summary_rows = []

    for mu in mus:
        for theta in thetas:
            force = ramp_force_n(mu, theta)
            pullers = pullers_required(mu, theta)
            distance = safety_distance_m(mu, theta)
            for headway_case in headway_cases:
                headway = dynamic_average_headway_min(mu, theta, headway_case)
                years_base = base_years(mu, theta, headway_case)
                n = len(stop_factor)
                headway_delta_min = rng.uniform(-0.5, 0.5, size=n)
                realized_headway_min = headway + headway_delta_min
                headway_multiplier = realized_headway_min / headway
                product = headway_multiplier * stop_factor
                combined_multiplier = product / np.median(product)
                durations = years_base * combined_multiplier
                scenario = f"mu{mu:.2f}_theta{theta:.0f}_headway{headway_case:.0f}".replace(".", "p")
                trials = pd.DataFrame(
                    {
                        "trial": np.arange(1, n + 1),
                        "scenario": scenario,
                        "duration_years": durations,
                        "base_duration_years": years_base,
                        "headway_case_min": headway_case,
                        "dynamic_average_headway_min": headway,
                        "physics_headway_min": safety_headway_min(mu, theta),
                        "headway_delta_min": headway_delta_min,
                        "realized_headway_min": realized_headway_min,
                        "headway_multiplier": headway_multiplier,
                        "stop_factor": stop_factor,
                        "combined_multiplier_centered": combined_multiplier,
                        "friction_mu": mu,
                        "theta_r_deg": theta,
                        "force_n": force,
                        "pullers_300n": pullers,
                        "team_length_m": team_length_from_scenario_m(mu, theta),
                        "safety_distance_m": distance,
                        "block_mass_kg": BLOCK_MASS_KG,
                        "g_m_s2": G,
                    }
                )
                trials.to_csv(out_dir / f"montecarlo_edge_ramp_trials_{scenario}_10000.csv", index=False)
                all_trials.append(trials)

                q025, q50, q975 = np.quantile(durations, [0.025, 0.5, 0.975])
                summary_rows.append(
                    {
                        "mu": mu,
                        "theta_deg": theta,
                        "headway_case_min": headway_case,
                        "force_n": force,
                        "pullers_300n": pullers,
                        "safety_distance_m": distance,
                        "physics_headway_min": safety_headway_min(mu, theta),
                        "dynamic_average_headway_min": headway,
                        "base_duration_years": years_base,
                        "median_years": q50,
                        "ci95_low": q025,
                        "ci95_high": q975,
                    }
                )

    summary = pd.DataFrame(summary_rows)
    trials = pd.concat(all_trials, ignore_index=True)
    summary.to_csv(out_dir / "montecarlo_edge_ramp_trials_summary_corrected.csv", index=False)
    trials.to_csv(out_dir / "montecarlo_edge_ramp_trials_all_corrected.csv", index=False)
    return summary, trials


if __name__ == "__main__":
    summary, _ = run_scenarios()
    with pd.option_context("display.max_columns", None, "display.width", 160):
        print(summary.round({
            "force_n": 0,
            "safety_distance_m": 2,
            "headway_mean_min": 3,
            "base_duration_years": 2,
            "median_years": 2,
            "ci95_low": 2,
            "ci95_high": 2,
        }).to_string(index=False))
